namespace Ccash.SemanticAnalysis.Nodes.Expressions
{
    public interface IRvalueExpression: IExpression
    {
    }
}
