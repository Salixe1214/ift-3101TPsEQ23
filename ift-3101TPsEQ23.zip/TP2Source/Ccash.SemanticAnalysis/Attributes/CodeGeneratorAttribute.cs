﻿namespace Ccash.SemanticAnalysis.Attributes
{
    public class CodeGeneratorAttribute
    {
        public object Data { get; set; }
        public object Block { get; set; }
    }
}