// Generated from c:\Users\Raouf\Documents\IFT-3101\TPs (1)\TPs\Ccash.Antlr\Ccash.g4 by ANTLR 4.8
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class CcashParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.8", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, Int8=9, 
		Uint8=10, Int16=11, Uint16=12, Int32=13, Uint32=14, Int64=15, Uint64=16, 
		Float32=17, Float64=18, Bool=19, True=20, False=21, LeftParen=22, RightParen=23, 
		LeftBracket=24, RightBracket=25, LeftBrace=26, RightBrace=27, DoubleQuote=28, 
		SingleQuote=29, Return=30, Func=31, Const=32, Mut=33, Static=34, If=35, 
		Else=36, While=37, Do=38, For=39, As=40, Ref=41, Class=42, Struct=43, 
		Repeat=44, Plus=45, Minus=46, Mul=47, Div=48, Mod=49, BitAnd=50, BitOr=51, 
		BitXor=52, Not=53, LogicalAnd=54, LogicalOr=55, Lesser=56, LesserEq=57, 
		Greater=58, GreaterEq=59, Equal=60, NotEqual=61, Ternary=62, Swap=63, 
		Assign=64, AddAssign=65, SubAssign=66, DivAssign=67, MulAssign=68, ModAssign=69, 
		AndAssign=70, OrAssign=71, XorAssign=72, Semicolon=73, Identifier=74, 
		ModuleSeparator=75, IntegerLiteral=76, UintegerLiteral=77, FloatLiteral=78, 
		Float32Literal=79, StringLiteral=80, Whitespace=81, Newline=82, BlockComment=83, 
		LineComment=84;
	public static final int
		RULE_compilationUnit = 0, RULE_functionDeclaration = 1, RULE_functionHeader = 2, 
		RULE_functionParameters = 3, RULE_functionCall = 4, RULE_functionArgs = 5, 
		RULE_structDeclaration = 6, RULE_field = 7, RULE_method = 8, RULE_methodHeader = 9, 
		RULE_variableDeclaration = 10, RULE_variable = 11, RULE_functionName = 12, 
		RULE_valueType = 13, RULE_referenceType = 14, RULE_arrayType = 15, RULE_variableType = 16, 
		RULE_type = 17, RULE_statement = 18, RULE_block = 19, RULE_ifStatement = 20, 
		RULE_elseIfStatement = 21, RULE_elseStatement = 22, RULE_returnStatement = 23, 
		RULE_reassignment = 24, RULE_whileHeader = 25, RULE_whileStatement = 26, 
		RULE_doStatement = 27, RULE_forHeader = 28, RULE_forStatement = 29, RULE_repeatStatement = 30, 
		RULE_forInitialization = 31, RULE_forUpdate = 32, RULE_expression = 33, 
		RULE_fieldInitializer = 34;
	private static String[] makeRuleNames() {
		return new String[] {
			"compilationUnit", "functionDeclaration", "functionHeader", "functionParameters", 
			"functionCall", "functionArgs", "structDeclaration", "field", "method", 
			"methodHeader", "variableDeclaration", "variable", "functionName", "valueType", 
			"referenceType", "arrayType", "variableType", "type", "statement", "block", 
			"ifStatement", "elseIfStatement", "elseStatement", "returnStatement", 
			"reassignment", "whileHeader", "whileStatement", "doStatement", "forHeader", 
			"forStatement", "repeatStatement", "forInitialization", "forUpdate", 
			"expression", "fieldInitializer"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "','", "'[]'", "'.'", "'--'", "'++'", "'<<'", "'>>'", "':'", "'int8'", 
			"'uint8'", "'int16'", "'uint16'", "'int32'", "'uint32'", "'int64'", "'uint64'", 
			"'float32'", "'float64'", "'bool'", "'true'", "'false'", "'('", "')'", 
			"'['", "']'", "'{'", "'}'", "'\"'", "'''", "'return'", "'func'", "'const'", 
			"'mut'", "'static'", "'if'", "'else'", "'while'", "'do'", "'for'", "'as'", 
			"'ref'", "'class'", "'struct'", "'repeat'", "'+'", "'-'", "'*'", "'/'", 
			"'%'", "'&'", "'|'", "'^'", "'!'", "'&&'", "'||'", "'<'", "'<='", "'>'", 
			"'>='", "'=='", "'!='", "'?'", "':=:'", "':='", "'+='", "'-='", "'/='", 
			"'*='", "'%='", "'&='", "'|='", "'^='", "';'", null, "'::'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, "Int8", "Uint8", 
			"Int16", "Uint16", "Int32", "Uint32", "Int64", "Uint64", "Float32", "Float64", 
			"Bool", "True", "False", "LeftParen", "RightParen", "LeftBracket", "RightBracket", 
			"LeftBrace", "RightBrace", "DoubleQuote", "SingleQuote", "Return", "Func", 
			"Const", "Mut", "Static", "If", "Else", "While", "Do", "For", "As", "Ref", 
			"Class", "Struct", "Repeat", "Plus", "Minus", "Mul", "Div", "Mod", "BitAnd", 
			"BitOr", "BitXor", "Not", "LogicalAnd", "LogicalOr", "Lesser", "LesserEq", 
			"Greater", "GreaterEq", "Equal", "NotEqual", "Ternary", "Swap", "Assign", 
			"AddAssign", "SubAssign", "DivAssign", "MulAssign", "ModAssign", "AndAssign", 
			"OrAssign", "XorAssign", "Semicolon", "Identifier", "ModuleSeparator", 
			"IntegerLiteral", "UintegerLiteral", "FloatLiteral", "Float32Literal", 
			"StringLiteral", "Whitespace", "Newline", "BlockComment", "LineComment"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Ccash.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public CcashParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class CompilationUnitContext extends ParserRuleContext {
		public TerminalNode EOF() { return getToken(CcashParser.EOF, 0); }
		public List<FunctionDeclarationContext> functionDeclaration() {
			return getRuleContexts(FunctionDeclarationContext.class);
		}
		public FunctionDeclarationContext functionDeclaration(int i) {
			return getRuleContext(FunctionDeclarationContext.class,i);
		}
		public List<StructDeclarationContext> structDeclaration() {
			return getRuleContexts(StructDeclarationContext.class);
		}
		public StructDeclarationContext structDeclaration(int i) {
			return getRuleContext(StructDeclarationContext.class,i);
		}
		public CompilationUnitContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_compilationUnit; }
	}

	public final CompilationUnitContext compilationUnit() throws RecognitionException {
		CompilationUnitContext _localctx = new CompilationUnitContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_compilationUnit);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(74);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Func) | (1L << Class) | (1L << Struct))) != 0)) {
				{
				setState(72);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case Func:
					{
					setState(70);
					functionDeclaration();
					}
					break;
				case Class:
				case Struct:
					{
					setState(71);
					structDeclaration();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(76);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(77);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FunctionDeclarationContext extends ParserRuleContext {
		public FunctionHeaderContext functionHeader() {
			return getRuleContext(FunctionHeaderContext.class,0);
		}
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public FunctionDeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functionDeclaration; }
	}

	public final FunctionDeclarationContext functionDeclaration() throws RecognitionException {
		FunctionDeclarationContext _localctx = new FunctionDeclarationContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_functionDeclaration);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(79);
			functionHeader();
			setState(80);
			block();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FunctionHeaderContext extends ParserRuleContext {
		public TerminalNode Func() { return getToken(CcashParser.Func, 0); }
		public TerminalNode Identifier() { return getToken(CcashParser.Identifier, 0); }
		public TerminalNode LeftParen() { return getToken(CcashParser.LeftParen, 0); }
		public TerminalNode RightParen() { return getToken(CcashParser.RightParen, 0); }
		public FunctionParametersContext functionParameters() {
			return getRuleContext(FunctionParametersContext.class,0);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public FunctionHeaderContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functionHeader; }
	}

	public final FunctionHeaderContext functionHeader() throws RecognitionException {
		FunctionHeaderContext _localctx = new FunctionHeaderContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_functionHeader);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(82);
			match(Func);
			setState(83);
			match(Identifier);
			setState(84);
			match(LeftParen);
			setState(86);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==Const || _la==Mut) {
				{
				setState(85);
				functionParameters();
				}
			}

			setState(88);
			match(RightParen);
			setState(90);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Int8) | (1L << Uint8) | (1L << Int16) | (1L << Uint16) | (1L << Int32) | (1L << Uint32) | (1L << Int64) | (1L << Uint64) | (1L << Float32) | (1L << Float64) | (1L << Bool) | (1L << Const) | (1L << Mut))) != 0) || _la==Identifier) {
				{
				setState(89);
				type();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FunctionParametersContext extends ParserRuleContext {
		public List<VariableContext> variable() {
			return getRuleContexts(VariableContext.class);
		}
		public VariableContext variable(int i) {
			return getRuleContext(VariableContext.class,i);
		}
		public FunctionParametersContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functionParameters; }
	}

	public final FunctionParametersContext functionParameters() throws RecognitionException {
		FunctionParametersContext _localctx = new FunctionParametersContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_functionParameters);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(92);
			variable();
			setState(97);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(93);
				match(T__0);
				setState(94);
				variable();
				}
				}
				setState(99);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FunctionCallContext extends ParserRuleContext {
		public FunctionNameContext functionName() {
			return getRuleContext(FunctionNameContext.class,0);
		}
		public TerminalNode LeftParen() { return getToken(CcashParser.LeftParen, 0); }
		public TerminalNode RightParen() { return getToken(CcashParser.RightParen, 0); }
		public FunctionArgsContext functionArgs() {
			return getRuleContext(FunctionArgsContext.class,0);
		}
		public FunctionCallContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functionCall; }
	}

	public final FunctionCallContext functionCall() throws RecognitionException {
		FunctionCallContext _localctx = new FunctionCallContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_functionCall);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(100);
			functionName();
			setState(101);
			match(LeftParen);
			setState(103);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Int8) | (1L << Uint8) | (1L << Int16) | (1L << Uint16) | (1L << Int32) | (1L << Uint32) | (1L << Int64) | (1L << Uint64) | (1L << Float32) | (1L << Float64) | (1L << Bool) | (1L << True) | (1L << False) | (1L << LeftParen) | (1L << LeftBracket) | (1L << Ref) | (1L << Minus) | (1L << Not))) != 0) || ((((_la - 74)) & ~0x3f) == 0 && ((1L << (_la - 74)) & ((1L << (Identifier - 74)) | (1L << (IntegerLiteral - 74)) | (1L << (UintegerLiteral - 74)) | (1L << (FloatLiteral - 74)) | (1L << (Float32Literal - 74)) | (1L << (StringLiteral - 74)))) != 0)) {
				{
				setState(102);
				functionArgs();
				}
			}

			setState(105);
			match(RightParen);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FunctionArgsContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public FunctionArgsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functionArgs; }
	}

	public final FunctionArgsContext functionArgs() throws RecognitionException {
		FunctionArgsContext _localctx = new FunctionArgsContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_functionArgs);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(107);
			expression(0);
			setState(112);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(108);
				match(T__0);
				setState(109);
				expression(0);
				}
				}
				setState(114);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StructDeclarationContext extends ParserRuleContext {
		public TerminalNode Identifier() { return getToken(CcashParser.Identifier, 0); }
		public TerminalNode LeftBrace() { return getToken(CcashParser.LeftBrace, 0); }
		public TerminalNode RightBrace() { return getToken(CcashParser.RightBrace, 0); }
		public TerminalNode Struct() { return getToken(CcashParser.Struct, 0); }
		public TerminalNode Class() { return getToken(CcashParser.Class, 0); }
		public List<FieldContext> field() {
			return getRuleContexts(FieldContext.class);
		}
		public FieldContext field(int i) {
			return getRuleContext(FieldContext.class,i);
		}
		public List<MethodContext> method() {
			return getRuleContexts(MethodContext.class);
		}
		public MethodContext method(int i) {
			return getRuleContext(MethodContext.class,i);
		}
		public StructDeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_structDeclaration; }
	}

	public final StructDeclarationContext structDeclaration() throws RecognitionException {
		StructDeclarationContext _localctx = new StructDeclarationContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_structDeclaration);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(115);
			_la = _input.LA(1);
			if ( !(_la==Class || _la==Struct) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(116);
			match(Identifier);
			setState(117);
			match(LeftBrace);
			setState(122);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Int8) | (1L << Uint8) | (1L << Int16) | (1L << Uint16) | (1L << Int32) | (1L << Uint32) | (1L << Int64) | (1L << Uint64) | (1L << Float32) | (1L << Float64) | (1L << Bool) | (1L << Func) | (1L << Const) | (1L << Mut))) != 0) || _la==Identifier) {
				{
				setState(120);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case Int8:
				case Uint8:
				case Int16:
				case Uint16:
				case Int32:
				case Uint32:
				case Int64:
				case Uint64:
				case Float32:
				case Float64:
				case Bool:
				case Const:
				case Mut:
				case Identifier:
					{
					setState(118);
					field();
					}
					break;
				case Func:
					{
					setState(119);
					method();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(124);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(125);
			match(RightBrace);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FieldContext extends ParserRuleContext {
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode Identifier() { return getToken(CcashParser.Identifier, 0); }
		public TerminalNode Semicolon() { return getToken(CcashParser.Semicolon, 0); }
		public FieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_field; }
	}

	public final FieldContext field() throws RecognitionException {
		FieldContext _localctx = new FieldContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_field);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(127);
			type();
			setState(128);
			match(Identifier);
			setState(129);
			match(Semicolon);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MethodContext extends ParserRuleContext {
		public MethodHeaderContext methodHeader() {
			return getRuleContext(MethodHeaderContext.class,0);
		}
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public MethodContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_method; }
	}

	public final MethodContext method() throws RecognitionException {
		MethodContext _localctx = new MethodContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_method);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(131);
			methodHeader();
			setState(132);
			block();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MethodHeaderContext extends ParserRuleContext {
		public TerminalNode Func() { return getToken(CcashParser.Func, 0); }
		public TerminalNode Identifier() { return getToken(CcashParser.Identifier, 0); }
		public TerminalNode LeftParen() { return getToken(CcashParser.LeftParen, 0); }
		public TerminalNode RightParen() { return getToken(CcashParser.RightParen, 0); }
		public TerminalNode Const() { return getToken(CcashParser.Const, 0); }
		public TerminalNode Mut() { return getToken(CcashParser.Mut, 0); }
		public TerminalNode Static() { return getToken(CcashParser.Static, 0); }
		public FunctionParametersContext functionParameters() {
			return getRuleContext(FunctionParametersContext.class,0);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public MethodHeaderContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_methodHeader; }
	}

	public final MethodHeaderContext methodHeader() throws RecognitionException {
		MethodHeaderContext _localctx = new MethodHeaderContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_methodHeader);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(134);
			match(Func);
			setState(135);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Const) | (1L << Mut) | (1L << Static))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(136);
			match(Identifier);
			setState(137);
			match(LeftParen);
			setState(139);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==Const || _la==Mut) {
				{
				setState(138);
				functionParameters();
				}
			}

			setState(141);
			match(RightParen);
			setState(143);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Int8) | (1L << Uint8) | (1L << Int16) | (1L << Uint16) | (1L << Int32) | (1L << Uint32) | (1L << Int64) | (1L << Uint64) | (1L << Float32) | (1L << Float64) | (1L << Bool) | (1L << Const) | (1L << Mut))) != 0) || _la==Identifier) {
				{
				setState(142);
				type();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VariableDeclarationContext extends ParserRuleContext {
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public TerminalNode Assign() { return getToken(CcashParser.Assign, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public VariableDeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_variableDeclaration; }
	}

	public final VariableDeclarationContext variableDeclaration() throws RecognitionException {
		VariableDeclarationContext _localctx = new VariableDeclarationContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_variableDeclaration);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(145);
			variable();
			setState(146);
			match(Assign);
			setState(147);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VariableContext extends ParserRuleContext {
		public VariableTypeContext variableType() {
			return getRuleContext(VariableTypeContext.class,0);
		}
		public TerminalNode Identifier() { return getToken(CcashParser.Identifier, 0); }
		public VariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_variable; }
	}

	public final VariableContext variable() throws RecognitionException {
		VariableContext _localctx = new VariableContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_variable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(149);
			variableType();
			setState(150);
			match(Identifier);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FunctionNameContext extends ParserRuleContext {
		public TerminalNode Identifier() { return getToken(CcashParser.Identifier, 0); }
		public TerminalNode Bool() { return getToken(CcashParser.Bool, 0); }
		public TerminalNode Int8() { return getToken(CcashParser.Int8, 0); }
		public TerminalNode Uint8() { return getToken(CcashParser.Uint8, 0); }
		public TerminalNode Int16() { return getToken(CcashParser.Int16, 0); }
		public TerminalNode Uint16() { return getToken(CcashParser.Uint16, 0); }
		public TerminalNode Int32() { return getToken(CcashParser.Int32, 0); }
		public TerminalNode Uint32() { return getToken(CcashParser.Uint32, 0); }
		public TerminalNode Int64() { return getToken(CcashParser.Int64, 0); }
		public TerminalNode Uint64() { return getToken(CcashParser.Uint64, 0); }
		public TerminalNode Float32() { return getToken(CcashParser.Float32, 0); }
		public TerminalNode Float64() { return getToken(CcashParser.Float64, 0); }
		public FunctionNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functionName; }
	}

	public final FunctionNameContext functionName() throws RecognitionException {
		FunctionNameContext _localctx = new FunctionNameContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_functionName);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(152);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Int8) | (1L << Uint8) | (1L << Int16) | (1L << Uint16) | (1L << Int32) | (1L << Uint32) | (1L << Int64) | (1L << Uint64) | (1L << Float32) | (1L << Float64) | (1L << Bool))) != 0) || _la==Identifier) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ValueTypeContext extends ParserRuleContext {
		public ValueTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_valueType; }
	 
		public ValueTypeContext() { }
		public void copyFrom(ValueTypeContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class BoolTypeContext extends ValueTypeContext {
		public TerminalNode Bool() { return getToken(CcashParser.Bool, 0); }
		public BoolTypeContext(ValueTypeContext ctx) { copyFrom(ctx); }
	}
	public static class StructTypeContext extends ValueTypeContext {
		public TerminalNode Identifier() { return getToken(CcashParser.Identifier, 0); }
		public StructTypeContext(ValueTypeContext ctx) { copyFrom(ctx); }
	}
	public static class IntegralTypeContext extends ValueTypeContext {
		public TerminalNode Int8() { return getToken(CcashParser.Int8, 0); }
		public TerminalNode Uint8() { return getToken(CcashParser.Uint8, 0); }
		public TerminalNode Int16() { return getToken(CcashParser.Int16, 0); }
		public TerminalNode Uint16() { return getToken(CcashParser.Uint16, 0); }
		public TerminalNode Int32() { return getToken(CcashParser.Int32, 0); }
		public TerminalNode Uint32() { return getToken(CcashParser.Uint32, 0); }
		public TerminalNode Int64() { return getToken(CcashParser.Int64, 0); }
		public TerminalNode Uint64() { return getToken(CcashParser.Uint64, 0); }
		public IntegralTypeContext(ValueTypeContext ctx) { copyFrom(ctx); }
	}
	public static class FloatTypeContext extends ValueTypeContext {
		public TerminalNode Float32() { return getToken(CcashParser.Float32, 0); }
		public TerminalNode Float64() { return getToken(CcashParser.Float64, 0); }
		public FloatTypeContext(ValueTypeContext ctx) { copyFrom(ctx); }
	}

	public final ValueTypeContext valueType() throws RecognitionException {
		ValueTypeContext _localctx = new ValueTypeContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_valueType);
		try {
			setState(166);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case Bool:
				_localctx = new BoolTypeContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(154);
				match(Bool);
				}
				break;
			case Int8:
				_localctx = new IntegralTypeContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(155);
				match(Int8);
				}
				break;
			case Uint8:
				_localctx = new IntegralTypeContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(156);
				match(Uint8);
				}
				break;
			case Int16:
				_localctx = new IntegralTypeContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(157);
				match(Int16);
				}
				break;
			case Uint16:
				_localctx = new IntegralTypeContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(158);
				match(Uint16);
				}
				break;
			case Int32:
				_localctx = new IntegralTypeContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(159);
				match(Int32);
				}
				break;
			case Uint32:
				_localctx = new IntegralTypeContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(160);
				match(Uint32);
				}
				break;
			case Int64:
				_localctx = new IntegralTypeContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(161);
				match(Int64);
				}
				break;
			case Uint64:
				_localctx = new IntegralTypeContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(162);
				match(Uint64);
				}
				break;
			case Float32:
				_localctx = new FloatTypeContext(_localctx);
				enterOuterAlt(_localctx, 10);
				{
				setState(163);
				match(Float32);
				}
				break;
			case Float64:
				_localctx = new FloatTypeContext(_localctx);
				enterOuterAlt(_localctx, 11);
				{
				setState(164);
				match(Float64);
				}
				break;
			case Identifier:
				_localctx = new StructTypeContext(_localctx);
				enterOuterAlt(_localctx, 12);
				{
				setState(165);
				match(Identifier);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ReferenceTypeContext extends ParserRuleContext {
		public TerminalNode Ref() { return getToken(CcashParser.Ref, 0); }
		public ValueTypeContext valueType() {
			return getRuleContext(ValueTypeContext.class,0);
		}
		public ReferenceTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_referenceType; }
	}

	public final ReferenceTypeContext referenceType() throws RecognitionException {
		ReferenceTypeContext _localctx = new ReferenceTypeContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_referenceType);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(168);
			match(Ref);
			setState(169);
			valueType();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArrayTypeContext extends ParserRuleContext {
		public ValueTypeContext valueType() {
			return getRuleContext(ValueTypeContext.class,0);
		}
		public ReferenceTypeContext referenceType() {
			return getRuleContext(ReferenceTypeContext.class,0);
		}
		public ArrayTypeContext arrayType() {
			return getRuleContext(ArrayTypeContext.class,0);
		}
		public ArrayTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arrayType; }
	}

	public final ArrayTypeContext arrayType() throws RecognitionException {
		ArrayTypeContext _localctx = new ArrayTypeContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_arrayType);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(171);
			match(T__1);
			setState(175);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case Int8:
			case Uint8:
			case Int16:
			case Uint16:
			case Int32:
			case Uint32:
			case Int64:
			case Uint64:
			case Float32:
			case Float64:
			case Bool:
			case Identifier:
				{
				setState(172);
				valueType();
				}
				break;
			case Ref:
				{
				setState(173);
				referenceType();
				}
				break;
			case T__1:
				{
				setState(174);
				arrayType();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VariableTypeContext extends ParserRuleContext {
		public TerminalNode Const() { return getToken(CcashParser.Const, 0); }
		public TerminalNode Mut() { return getToken(CcashParser.Mut, 0); }
		public ValueTypeContext valueType() {
			return getRuleContext(ValueTypeContext.class,0);
		}
		public ReferenceTypeContext referenceType() {
			return getRuleContext(ReferenceTypeContext.class,0);
		}
		public ArrayTypeContext arrayType() {
			return getRuleContext(ArrayTypeContext.class,0);
		}
		public VariableTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_variableType; }
	}

	public final VariableTypeContext variableType() throws RecognitionException {
		VariableTypeContext _localctx = new VariableTypeContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_variableType);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(177);
			_la = _input.LA(1);
			if ( !(_la==Const || _la==Mut) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(181);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case Int8:
			case Uint8:
			case Int16:
			case Uint16:
			case Int32:
			case Uint32:
			case Int64:
			case Uint64:
			case Float32:
			case Float64:
			case Bool:
			case Identifier:
				{
				setState(178);
				valueType();
				}
				break;
			case Ref:
				{
				setState(179);
				referenceType();
				}
				break;
			case T__1:
				{
				setState(180);
				arrayType();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TypeContext extends ParserRuleContext {
		public ValueTypeContext valueType() {
			return getRuleContext(ValueTypeContext.class,0);
		}
		public TerminalNode Const() { return getToken(CcashParser.Const, 0); }
		public TerminalNode Mut() { return getToken(CcashParser.Mut, 0); }
		public ReferenceTypeContext referenceType() {
			return getRuleContext(ReferenceTypeContext.class,0);
		}
		public ArrayTypeContext arrayType() {
			return getRuleContext(ArrayTypeContext.class,0);
		}
		public TypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type; }
	}

	public final TypeContext type() throws RecognitionException {
		TypeContext _localctx = new TypeContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_type);
		int _la;
		try {
			setState(189);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case Int8:
			case Uint8:
			case Int16:
			case Uint16:
			case Int32:
			case Uint32:
			case Int64:
			case Uint64:
			case Float32:
			case Float64:
			case Bool:
			case Identifier:
				enterOuterAlt(_localctx, 1);
				{
				setState(183);
				valueType();
				}
				break;
			case Const:
			case Mut:
				enterOuterAlt(_localctx, 2);
				{
				{
				setState(184);
				_la = _input.LA(1);
				if ( !(_la==Const || _la==Mut) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(187);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case Ref:
					{
					setState(185);
					referenceType();
					}
					break;
				case T__1:
					{
					setState(186);
					arrayType();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatementContext extends ParserRuleContext {
		public StatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statement; }
	 
		public StatementContext() { }
		public void copyFrom(StatementContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ReassignmentStatementContext extends StatementContext {
		public ReassignmentContext reassignment() {
			return getRuleContext(ReassignmentContext.class,0);
		}
		public TerminalNode Semicolon() { return getToken(CcashParser.Semicolon, 0); }
		public ReassignmentStatementContext(StatementContext ctx) { copyFrom(ctx); }
	}
	public static class ConditionalStatementContext extends StatementContext {
		public IfStatementContext ifStatement() {
			return getRuleContext(IfStatementContext.class,0);
		}
		public ConditionalStatementContext(StatementContext ctx) { copyFrom(ctx); }
	}
	public static class MethodCallStatementContext extends StatementContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode Identifier() { return getToken(CcashParser.Identifier, 0); }
		public TerminalNode LeftParen() { return getToken(CcashParser.LeftParen, 0); }
		public TerminalNode RightParen() { return getToken(CcashParser.RightParen, 0); }
		public TerminalNode Semicolon() { return getToken(CcashParser.Semicolon, 0); }
		public FunctionArgsContext functionArgs() {
			return getRuleContext(FunctionArgsContext.class,0);
		}
		public MethodCallStatementContext(StatementContext ctx) { copyFrom(ctx); }
	}
	public static class FunctionCallStatementContext extends StatementContext {
		public FunctionCallContext functionCall() {
			return getRuleContext(FunctionCallContext.class,0);
		}
		public TerminalNode Semicolon() { return getToken(CcashParser.Semicolon, 0); }
		public FunctionCallStatementContext(StatementContext ctx) { copyFrom(ctx); }
	}
	public static class VariableDeclarationStatementContext extends StatementContext {
		public VariableDeclarationContext variableDeclaration() {
			return getRuleContext(VariableDeclarationContext.class,0);
		}
		public TerminalNode Semicolon() { return getToken(CcashParser.Semicolon, 0); }
		public VariableDeclarationStatementContext(StatementContext ctx) { copyFrom(ctx); }
	}
	public static class BlockStatementContext extends StatementContext {
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public BlockStatementContext(StatementContext ctx) { copyFrom(ctx); }
	}
	public static class LoopStatementContext extends StatementContext {
		public WhileStatementContext whileStatement() {
			return getRuleContext(WhileStatementContext.class,0);
		}
		public DoStatementContext doStatement() {
			return getRuleContext(DoStatementContext.class,0);
		}
		public ForStatementContext forStatement() {
			return getRuleContext(ForStatementContext.class,0);
		}
		public LoopStatementContext(StatementContext ctx) { copyFrom(ctx); }
	}
	public static class ControlFlowStatementContext extends StatementContext {
		public ReturnStatementContext returnStatement() {
			return getRuleContext(ReturnStatementContext.class,0);
		}
		public ControlFlowStatementContext(StatementContext ctx) { copyFrom(ctx); }
	}

	public final StatementContext statement() throws RecognitionException {
		StatementContext _localctx = new StatementContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_statement);
		int _la;
		try {
			setState(216);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,17,_ctx) ) {
			case 1:
				_localctx = new BlockStatementContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(191);
				block();
				}
				break;
			case 2:
				_localctx = new ConditionalStatementContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(192);
				ifStatement();
				}
				break;
			case 3:
				_localctx = new MethodCallStatementContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(193);
				expression(0);
				setState(194);
				match(T__2);
				setState(195);
				match(Identifier);
				setState(196);
				match(LeftParen);
				setState(198);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Int8) | (1L << Uint8) | (1L << Int16) | (1L << Uint16) | (1L << Int32) | (1L << Uint32) | (1L << Int64) | (1L << Uint64) | (1L << Float32) | (1L << Float64) | (1L << Bool) | (1L << True) | (1L << False) | (1L << LeftParen) | (1L << LeftBracket) | (1L << Ref) | (1L << Minus) | (1L << Not))) != 0) || ((((_la - 74)) & ~0x3f) == 0 && ((1L << (_la - 74)) & ((1L << (Identifier - 74)) | (1L << (IntegerLiteral - 74)) | (1L << (UintegerLiteral - 74)) | (1L << (FloatLiteral - 74)) | (1L << (Float32Literal - 74)) | (1L << (StringLiteral - 74)))) != 0)) {
					{
					setState(197);
					functionArgs();
					}
				}

				setState(200);
				match(RightParen);
				setState(201);
				match(Semicolon);
				}
				break;
			case 4:
				_localctx = new FunctionCallStatementContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(203);
				functionCall();
				setState(204);
				match(Semicolon);
				}
				break;
			case 5:
				_localctx = new VariableDeclarationStatementContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(206);
				variableDeclaration();
				setState(207);
				match(Semicolon);
				}
				break;
			case 6:
				_localctx = new ReassignmentStatementContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(209);
				reassignment();
				setState(210);
				match(Semicolon);
				}
				break;
			case 7:
				_localctx = new LoopStatementContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(212);
				whileStatement();
				}
				break;
			case 8:
				_localctx = new LoopStatementContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(213);
				doStatement();
				}
				break;
			case 9:
				_localctx = new LoopStatementContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(214);
				forStatement();
				}
				break;
			case 10:
				_localctx = new ControlFlowStatementContext(_localctx);
				enterOuterAlt(_localctx, 10);
				{
				setState(215);
				returnStatement();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BlockContext extends ParserRuleContext {
		public TerminalNode LeftBrace() { return getToken(CcashParser.LeftBrace, 0); }
		public TerminalNode RightBrace() { return getToken(CcashParser.RightBrace, 0); }
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public BlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_block; }
	}

	public final BlockContext block() throws RecognitionException {
		BlockContext _localctx = new BlockContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_block);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(218);
			match(LeftBrace);
			setState(222);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Int8) | (1L << Uint8) | (1L << Int16) | (1L << Uint16) | (1L << Int32) | (1L << Uint32) | (1L << Int64) | (1L << Uint64) | (1L << Float32) | (1L << Float64) | (1L << Bool) | (1L << True) | (1L << False) | (1L << LeftParen) | (1L << LeftBracket) | (1L << LeftBrace) | (1L << Return) | (1L << Const) | (1L << Mut) | (1L << If) | (1L << While) | (1L << Do) | (1L << For) | (1L << Ref) | (1L << Minus) | (1L << Not))) != 0) || ((((_la - 74)) & ~0x3f) == 0 && ((1L << (_la - 74)) & ((1L << (Identifier - 74)) | (1L << (IntegerLiteral - 74)) | (1L << (UintegerLiteral - 74)) | (1L << (FloatLiteral - 74)) | (1L << (Float32Literal - 74)) | (1L << (StringLiteral - 74)))) != 0)) {
				{
				{
				setState(219);
				statement();
				}
				}
				setState(224);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(225);
			match(RightBrace);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IfStatementContext extends ParserRuleContext {
		public TerminalNode If() { return getToken(CcashParser.If, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public List<ElseIfStatementContext> elseIfStatement() {
			return getRuleContexts(ElseIfStatementContext.class);
		}
		public ElseIfStatementContext elseIfStatement(int i) {
			return getRuleContext(ElseIfStatementContext.class,i);
		}
		public ElseStatementContext elseStatement() {
			return getRuleContext(ElseStatementContext.class,0);
		}
		public IfStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ifStatement; }
	}

	public final IfStatementContext ifStatement() throws RecognitionException {
		IfStatementContext _localctx = new IfStatementContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_ifStatement);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(227);
			match(If);
			setState(228);
			expression(0);
			setState(229);
			block();
			setState(233);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,19,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(230);
					elseIfStatement();
					}
					} 
				}
				setState(235);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,19,_ctx);
			}
			setState(237);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==Else) {
				{
				setState(236);
				elseStatement();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ElseIfStatementContext extends ParserRuleContext {
		public TerminalNode Else() { return getToken(CcashParser.Else, 0); }
		public TerminalNode If() { return getToken(CcashParser.If, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public ElseIfStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elseIfStatement; }
	}

	public final ElseIfStatementContext elseIfStatement() throws RecognitionException {
		ElseIfStatementContext _localctx = new ElseIfStatementContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_elseIfStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(239);
			match(Else);
			setState(240);
			match(If);
			setState(241);
			expression(0);
			setState(242);
			block();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ElseStatementContext extends ParserRuleContext {
		public TerminalNode Else() { return getToken(CcashParser.Else, 0); }
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public ElseStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elseStatement; }
	}

	public final ElseStatementContext elseStatement() throws RecognitionException {
		ElseStatementContext _localctx = new ElseStatementContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_elseStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(244);
			match(Else);
			setState(245);
			block();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ReturnStatementContext extends ParserRuleContext {
		public TerminalNode Return() { return getToken(CcashParser.Return, 0); }
		public TerminalNode Semicolon() { return getToken(CcashParser.Semicolon, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ReturnStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_returnStatement; }
	}

	public final ReturnStatementContext returnStatement() throws RecognitionException {
		ReturnStatementContext _localctx = new ReturnStatementContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_returnStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(247);
			match(Return);
			setState(249);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Int8) | (1L << Uint8) | (1L << Int16) | (1L << Uint16) | (1L << Int32) | (1L << Uint32) | (1L << Int64) | (1L << Uint64) | (1L << Float32) | (1L << Float64) | (1L << Bool) | (1L << True) | (1L << False) | (1L << LeftParen) | (1L << LeftBracket) | (1L << Ref) | (1L << Minus) | (1L << Not))) != 0) || ((((_la - 74)) & ~0x3f) == 0 && ((1L << (_la - 74)) & ((1L << (Identifier - 74)) | (1L << (IntegerLiteral - 74)) | (1L << (UintegerLiteral - 74)) | (1L << (FloatLiteral - 74)) | (1L << (Float32Literal - 74)) | (1L << (StringLiteral - 74)))) != 0)) {
				{
				setState(248);
				expression(0);
				}
			}

			setState(251);
			match(Semicolon);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ReassignmentContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode Swap() { return getToken(CcashParser.Swap, 0); }
		public TerminalNode Assign() { return getToken(CcashParser.Assign, 0); }
		public TerminalNode AddAssign() { return getToken(CcashParser.AddAssign, 0); }
		public TerminalNode SubAssign() { return getToken(CcashParser.SubAssign, 0); }
		public TerminalNode DivAssign() { return getToken(CcashParser.DivAssign, 0); }
		public TerminalNode MulAssign() { return getToken(CcashParser.MulAssign, 0); }
		public TerminalNode ModAssign() { return getToken(CcashParser.ModAssign, 0); }
		public TerminalNode AndAssign() { return getToken(CcashParser.AndAssign, 0); }
		public TerminalNode XorAssign() { return getToken(CcashParser.XorAssign, 0); }
		public TerminalNode OrAssign() { return getToken(CcashParser.OrAssign, 0); }
		public ReassignmentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_reassignment; }
	}

	public final ReassignmentContext reassignment() throws RecognitionException {
		ReassignmentContext _localctx = new ReassignmentContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_reassignment);
		int _la;
		try {
			setState(272);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,22,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(253);
				expression(0);
				setState(254);
				match(Swap);
				setState(255);
				expression(0);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(257);
				expression(0);
				setState(258);
				match(Assign);
				setState(259);
				expression(0);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(261);
				expression(0);
				setState(262);
				_la = _input.LA(1);
				if ( !(((((_la - 65)) & ~0x3f) == 0 && ((1L << (_la - 65)) & ((1L << (AddAssign - 65)) | (1L << (SubAssign - 65)) | (1L << (DivAssign - 65)) | (1L << (MulAssign - 65)))) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(263);
				expression(0);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(265);
				expression(0);
				setState(266);
				_la = _input.LA(1);
				if ( !(((((_la - 69)) & ~0x3f) == 0 && ((1L << (_la - 69)) & ((1L << (ModAssign - 69)) | (1L << (AndAssign - 69)) | (1L << (OrAssign - 69)) | (1L << (XorAssign - 69)))) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(267);
				expression(0);
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(269);
				expression(0);
				setState(270);
				_la = _input.LA(1);
				if ( !(_la==T__3 || _la==T__4) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class WhileHeaderContext extends ParserRuleContext {
		public TerminalNode While() { return getToken(CcashParser.While, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public WhileHeaderContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_whileHeader; }
	}

	public final WhileHeaderContext whileHeader() throws RecognitionException {
		WhileHeaderContext _localctx = new WhileHeaderContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_whileHeader);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(274);
			match(While);
			setState(275);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class WhileStatementContext extends ParserRuleContext {
		public WhileHeaderContext whileHeader() {
			return getRuleContext(WhileHeaderContext.class,0);
		}
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public WhileStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_whileStatement; }
	}

	public final WhileStatementContext whileStatement() throws RecognitionException {
		WhileStatementContext _localctx = new WhileStatementContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_whileStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(277);
			whileHeader();
			setState(278);
			block();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DoStatementContext extends ParserRuleContext {
		public TerminalNode Do() { return getToken(CcashParser.Do, 0); }
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public WhileHeaderContext whileHeader() {
			return getRuleContext(WhileHeaderContext.class,0);
		}
		public DoStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_doStatement; }
	}

	public final DoStatementContext doStatement() throws RecognitionException {
		DoStatementContext _localctx = new DoStatementContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_doStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(280);
			match(Do);
			setState(281);
			block();
			setState(282);
			whileHeader();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ForHeaderContext extends ParserRuleContext {
		public TerminalNode For() { return getToken(CcashParser.For, 0); }
		public List<TerminalNode> Semicolon() { return getTokens(CcashParser.Semicolon); }
		public TerminalNode Semicolon(int i) {
			return getToken(CcashParser.Semicolon, i);
		}
		public ForInitializationContext forInitialization() {
			return getRuleContext(ForInitializationContext.class,0);
		}
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ForUpdateContext forUpdate() {
			return getRuleContext(ForUpdateContext.class,0);
		}
		public ForHeaderContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_forHeader; }
	}

	public final ForHeaderContext forHeader() throws RecognitionException {
		ForHeaderContext _localctx = new ForHeaderContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_forHeader);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(284);
			match(For);
			setState(286);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Int8) | (1L << Uint8) | (1L << Int16) | (1L << Uint16) | (1L << Int32) | (1L << Uint32) | (1L << Int64) | (1L << Uint64) | (1L << Float32) | (1L << Float64) | (1L << Bool) | (1L << True) | (1L << False) | (1L << LeftParen) | (1L << LeftBracket) | (1L << Const) | (1L << Mut) | (1L << Ref) | (1L << Minus) | (1L << Not))) != 0) || ((((_la - 74)) & ~0x3f) == 0 && ((1L << (_la - 74)) & ((1L << (Identifier - 74)) | (1L << (IntegerLiteral - 74)) | (1L << (UintegerLiteral - 74)) | (1L << (FloatLiteral - 74)) | (1L << (Float32Literal - 74)) | (1L << (StringLiteral - 74)))) != 0)) {
				{
				setState(285);
				forInitialization();
				}
			}

			setState(288);
			match(Semicolon);
			setState(290);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Int8) | (1L << Uint8) | (1L << Int16) | (1L << Uint16) | (1L << Int32) | (1L << Uint32) | (1L << Int64) | (1L << Uint64) | (1L << Float32) | (1L << Float64) | (1L << Bool) | (1L << True) | (1L << False) | (1L << LeftParen) | (1L << LeftBracket) | (1L << Ref) | (1L << Minus) | (1L << Not))) != 0) || ((((_la - 74)) & ~0x3f) == 0 && ((1L << (_la - 74)) & ((1L << (Identifier - 74)) | (1L << (IntegerLiteral - 74)) | (1L << (UintegerLiteral - 74)) | (1L << (FloatLiteral - 74)) | (1L << (Float32Literal - 74)) | (1L << (StringLiteral - 74)))) != 0)) {
				{
				setState(289);
				expression(0);
				}
			}

			setState(292);
			match(Semicolon);
			setState(294);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Int8) | (1L << Uint8) | (1L << Int16) | (1L << Uint16) | (1L << Int32) | (1L << Uint32) | (1L << Int64) | (1L << Uint64) | (1L << Float32) | (1L << Float64) | (1L << Bool) | (1L << True) | (1L << False) | (1L << LeftParen) | (1L << LeftBracket) | (1L << Ref) | (1L << Minus) | (1L << Not))) != 0) || ((((_la - 74)) & ~0x3f) == 0 && ((1L << (_la - 74)) & ((1L << (Identifier - 74)) | (1L << (IntegerLiteral - 74)) | (1L << (UintegerLiteral - 74)) | (1L << (FloatLiteral - 74)) | (1L << (Float32Literal - 74)) | (1L << (StringLiteral - 74)))) != 0)) {
				{
				setState(293);
				forUpdate();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ForStatementContext extends ParserRuleContext {
		public ForHeaderContext forHeader() {
			return getRuleContext(ForHeaderContext.class,0);
		}
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public ForStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_forStatement; }
	}

	public final ForStatementContext forStatement() throws RecognitionException {
		ForStatementContext _localctx = new ForStatementContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_forStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(296);
			forHeader();
			setState(297);
			block();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RepeatStatementContext extends ParserRuleContext {
		public TerminalNode Repeat() { return getToken(CcashParser.Repeat, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public RepeatStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_repeatStatement; }
	}

	public final RepeatStatementContext repeatStatement() throws RecognitionException {
		RepeatStatementContext _localctx = new RepeatStatementContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_repeatStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(299);
			match(Repeat);
			setState(300);
			expression(0);
			setState(301);
			block();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ForInitializationContext extends ParserRuleContext {
		public FunctionCallContext functionCall() {
			return getRuleContext(FunctionCallContext.class,0);
		}
		public VariableDeclarationContext variableDeclaration() {
			return getRuleContext(VariableDeclarationContext.class,0);
		}
		public ReassignmentContext reassignment() {
			return getRuleContext(ReassignmentContext.class,0);
		}
		public ForInitializationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_forInitialization; }
	}

	public final ForInitializationContext forInitialization() throws RecognitionException {
		ForInitializationContext _localctx = new ForInitializationContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_forInitialization);
		try {
			setState(306);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,26,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(303);
				functionCall();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(304);
				variableDeclaration();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(305);
				reassignment();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ForUpdateContext extends ParserRuleContext {
		public FunctionCallContext functionCall() {
			return getRuleContext(FunctionCallContext.class,0);
		}
		public ReassignmentContext reassignment() {
			return getRuleContext(ReassignmentContext.class,0);
		}
		public ForUpdateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_forUpdate; }
	}

	public final ForUpdateContext forUpdate() throws RecognitionException {
		ForUpdateContext _localctx = new ForUpdateContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_forUpdate);
		try {
			setState(310);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,27,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(308);
				functionCall();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(309);
				reassignment();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionContext extends ParserRuleContext {
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
	 
		public ExpressionContext() { }
		public void copyFrom(ExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class TernaryExpressionContext extends ExpressionContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode Ternary() { return getToken(CcashParser.Ternary, 0); }
		public TernaryExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class MemberAccessExpressionContext extends ExpressionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode Identifier() { return getToken(CcashParser.Identifier, 0); }
		public MemberAccessExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class Float32LiteralExpressionContext extends ExpressionContext {
		public TerminalNode Float32Literal() { return getToken(CcashParser.Float32Literal, 0); }
		public Float32LiteralExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class UnaryOperatorExpressionContext extends ExpressionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode Minus() { return getToken(CcashParser.Minus, 0); }
		public TerminalNode Not() { return getToken(CcashParser.Not, 0); }
		public UnaryOperatorExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class FloatLiteralExpressionContext extends ExpressionContext {
		public TerminalNode FloatLiteral() { return getToken(CcashParser.FloatLiteral, 0); }
		public FloatLiteralExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class StringLiteralExpressionContext extends ExpressionContext {
		public TerminalNode StringLiteral() { return getToken(CcashParser.StringLiteral, 0); }
		public StringLiteralExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class ParenthesisExpressionContext extends ExpressionContext {
		public TerminalNode LeftParen() { return getToken(CcashParser.LeftParen, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode RightParen() { return getToken(CcashParser.RightParen, 0); }
		public ParenthesisExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class ArrayLiteralExpressionContext extends ExpressionContext {
		public TerminalNode LeftBracket() { return getToken(CcashParser.LeftBracket, 0); }
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode RightBracket() { return getToken(CcashParser.RightBracket, 0); }
		public ArrayLiteralExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class StructLiteralExpressionContext extends ExpressionContext {
		public TerminalNode Identifier() { return getToken(CcashParser.Identifier, 0); }
		public TerminalNode LeftBrace() { return getToken(CcashParser.LeftBrace, 0); }
		public TerminalNode RightBrace() { return getToken(CcashParser.RightBrace, 0); }
		public List<FieldInitializerContext> fieldInitializer() {
			return getRuleContexts(FieldInitializerContext.class);
		}
		public FieldInitializerContext fieldInitializer(int i) {
			return getRuleContext(FieldInitializerContext.class,i);
		}
		public StructLiteralExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class FunctionCallExpressionContext extends ExpressionContext {
		public FunctionCallContext functionCall() {
			return getRuleContext(FunctionCallContext.class,0);
		}
		public FunctionCallExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class IdentifierExpressionContext extends ExpressionContext {
		public TerminalNode Identifier() { return getToken(CcashParser.Identifier, 0); }
		public IdentifierExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class IndexOperatorExpressionContext extends ExpressionContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode LeftBracket() { return getToken(CcashParser.LeftBracket, 0); }
		public TerminalNode RightBracket() { return getToken(CcashParser.RightBracket, 0); }
		public IndexOperatorExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class RefExpressionContext extends ExpressionContext {
		public TerminalNode Ref() { return getToken(CcashParser.Ref, 0); }
		public TerminalNode Identifier() { return getToken(CcashParser.Identifier, 0); }
		public RefExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class BinaryOperatorExpressionContext extends ExpressionContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode Mul() { return getToken(CcashParser.Mul, 0); }
		public TerminalNode Div() { return getToken(CcashParser.Div, 0); }
		public TerminalNode Mod() { return getToken(CcashParser.Mod, 0); }
		public TerminalNode Plus() { return getToken(CcashParser.Plus, 0); }
		public TerminalNode Minus() { return getToken(CcashParser.Minus, 0); }
		public TerminalNode Lesser() { return getToken(CcashParser.Lesser, 0); }
		public TerminalNode LesserEq() { return getToken(CcashParser.LesserEq, 0); }
		public TerminalNode Greater() { return getToken(CcashParser.Greater, 0); }
		public TerminalNode GreaterEq() { return getToken(CcashParser.GreaterEq, 0); }
		public TerminalNode Equal() { return getToken(CcashParser.Equal, 0); }
		public TerminalNode NotEqual() { return getToken(CcashParser.NotEqual, 0); }
		public TerminalNode BitAnd() { return getToken(CcashParser.BitAnd, 0); }
		public TerminalNode BitXor() { return getToken(CcashParser.BitXor, 0); }
		public TerminalNode BitOr() { return getToken(CcashParser.BitOr, 0); }
		public TerminalNode LogicalAnd() { return getToken(CcashParser.LogicalAnd, 0); }
		public TerminalNode LogicalOr() { return getToken(CcashParser.LogicalOr, 0); }
		public BinaryOperatorExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class MethodCallExpressionContext extends ExpressionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode Identifier() { return getToken(CcashParser.Identifier, 0); }
		public TerminalNode LeftParen() { return getToken(CcashParser.LeftParen, 0); }
		public TerminalNode RightParen() { return getToken(CcashParser.RightParen, 0); }
		public FunctionArgsContext functionArgs() {
			return getRuleContext(FunctionArgsContext.class,0);
		}
		public MethodCallExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class IntegerLiteralExpressionContext extends ExpressionContext {
		public TerminalNode IntegerLiteral() { return getToken(CcashParser.IntegerLiteral, 0); }
		public TerminalNode UintegerLiteral() { return getToken(CcashParser.UintegerLiteral, 0); }
		public IntegerLiteralExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}
	public static class BooleanLiteralExpressionContext extends ExpressionContext {
		public TerminalNode True() { return getToken(CcashParser.True, 0); }
		public TerminalNode False() { return getToken(CcashParser.False, 0); }
		public BooleanLiteralExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
	}

	public final ExpressionContext expression() throws RecognitionException {
		return expression(0);
	}

	private ExpressionContext expression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExpressionContext _localctx = new ExpressionContext(_ctx, _parentState);
		ExpressionContext _prevctx = _localctx;
		int _startState = 66;
		enterRecursionRule(_localctx, 66, RULE_expression, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(353);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,31,_ctx) ) {
			case 1:
				{
				_localctx = new ParenthesisExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(313);
				match(LeftParen);
				setState(314);
				expression(0);
				setState(315);
				match(RightParen);
				}
				break;
			case 2:
				{
				_localctx = new IntegerLiteralExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(317);
				match(IntegerLiteral);
				}
				break;
			case 3:
				{
				_localctx = new IntegerLiteralExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(318);
				match(UintegerLiteral);
				}
				break;
			case 4:
				{
				_localctx = new FloatLiteralExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(319);
				match(FloatLiteral);
				}
				break;
			case 5:
				{
				_localctx = new Float32LiteralExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(320);
				match(Float32Literal);
				}
				break;
			case 6:
				{
				_localctx = new StringLiteralExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(321);
				match(StringLiteral);
				}
				break;
			case 7:
				{
				_localctx = new StructLiteralExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(322);
				match(Identifier);
				setState(323);
				match(LeftBrace);
				setState(332);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==Identifier) {
					{
					setState(324);
					fieldInitializer();
					setState(329);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==T__0) {
						{
						{
						setState(325);
						match(T__0);
						setState(326);
						fieldInitializer();
						}
						}
						setState(331);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
				}

				setState(334);
				match(RightBrace);
				}
				break;
			case 8:
				{
				_localctx = new IdentifierExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(335);
				match(Identifier);
				}
				break;
			case 9:
				{
				_localctx = new BooleanLiteralExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(336);
				_la = _input.LA(1);
				if ( !(_la==True || _la==False) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case 10:
				{
				_localctx = new FunctionCallExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(337);
				functionCall();
				}
				break;
			case 11:
				{
				_localctx = new ArrayLiteralExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(338);
				match(LeftBracket);
				setState(339);
				expression(0);
				setState(344);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(340);
					match(T__0);
					setState(341);
					expression(0);
					}
					}
					setState(346);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(347);
				match(RightBracket);
				}
				break;
			case 12:
				{
				_localctx = new RefExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(349);
				match(Ref);
				setState(350);
				match(Identifier);
				}
				break;
			case 13:
				{
				_localctx = new UnaryOperatorExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(351);
				_la = _input.LA(1);
				if ( !(_la==Minus || _la==Not) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(352);
				expression(12);
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(409);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,34,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(407);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,33,_ctx) ) {
					case 1:
						{
						_localctx = new BinaryOperatorExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(355);
						if (!(precpred(_ctx, 11))) throw new FailedPredicateException(this, "precpred(_ctx, 11)");
						setState(356);
						_la = _input.LA(1);
						if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Mul) | (1L << Div) | (1L << Mod))) != 0)) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(357);
						expression(12);
						}
						break;
					case 2:
						{
						_localctx = new BinaryOperatorExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(358);
						if (!(precpred(_ctx, 10))) throw new FailedPredicateException(this, "precpred(_ctx, 10)");
						setState(359);
						_la = _input.LA(1);
						if ( !(_la==Plus || _la==Minus) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(360);
						expression(11);
						}
						break;
					case 3:
						{
						_localctx = new BinaryOperatorExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(361);
						if (!(precpred(_ctx, 9))) throw new FailedPredicateException(this, "precpred(_ctx, 9)");
						setState(362);
						_la = _input.LA(1);
						if ( !(_la==T__5 || _la==T__6) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(363);
						expression(10);
						}
						break;
					case 4:
						{
						_localctx = new BinaryOperatorExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(364);
						if (!(precpred(_ctx, 8))) throw new FailedPredicateException(this, "precpred(_ctx, 8)");
						setState(365);
						_la = _input.LA(1);
						if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Lesser) | (1L << LesserEq) | (1L << Greater) | (1L << GreaterEq))) != 0)) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(366);
						expression(9);
						}
						break;
					case 5:
						{
						_localctx = new BinaryOperatorExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(367);
						if (!(precpred(_ctx, 7))) throw new FailedPredicateException(this, "precpred(_ctx, 7)");
						setState(368);
						_la = _input.LA(1);
						if ( !(_la==Equal || _la==NotEqual) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(369);
						expression(8);
						}
						break;
					case 6:
						{
						_localctx = new BinaryOperatorExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(370);
						if (!(precpred(_ctx, 6))) throw new FailedPredicateException(this, "precpred(_ctx, 6)");
						setState(371);
						match(BitAnd);
						setState(372);
						expression(7);
						}
						break;
					case 7:
						{
						_localctx = new BinaryOperatorExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(373);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(374);
						match(BitXor);
						setState(375);
						expression(6);
						}
						break;
					case 8:
						{
						_localctx = new BinaryOperatorExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(376);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(377);
						match(BitOr);
						setState(378);
						expression(5);
						}
						break;
					case 9:
						{
						_localctx = new BinaryOperatorExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(379);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(380);
						match(LogicalAnd);
						setState(381);
						expression(4);
						}
						break;
					case 10:
						{
						_localctx = new BinaryOperatorExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(382);
						if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
						setState(383);
						match(LogicalOr);
						setState(384);
						expression(3);
						}
						break;
					case 11:
						{
						_localctx = new TernaryExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(385);
						if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
						setState(386);
						match(Ternary);
						setState(387);
						expression(0);
						setState(388);
						match(T__7);
						setState(389);
						expression(2);
						}
						break;
					case 12:
						{
						_localctx = new MethodCallExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(391);
						if (!(precpred(_ctx, 18))) throw new FailedPredicateException(this, "precpred(_ctx, 18)");
						setState(392);
						match(T__2);
						setState(393);
						match(Identifier);
						setState(394);
						match(LeftParen);
						setState(396);
						_errHandler.sync(this);
						_la = _input.LA(1);
						if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Int8) | (1L << Uint8) | (1L << Int16) | (1L << Uint16) | (1L << Int32) | (1L << Uint32) | (1L << Int64) | (1L << Uint64) | (1L << Float32) | (1L << Float64) | (1L << Bool) | (1L << True) | (1L << False) | (1L << LeftParen) | (1L << LeftBracket) | (1L << Ref) | (1L << Minus) | (1L << Not))) != 0) || ((((_la - 74)) & ~0x3f) == 0 && ((1L << (_la - 74)) & ((1L << (Identifier - 74)) | (1L << (IntegerLiteral - 74)) | (1L << (UintegerLiteral - 74)) | (1L << (FloatLiteral - 74)) | (1L << (Float32Literal - 74)) | (1L << (StringLiteral - 74)))) != 0)) {
							{
							setState(395);
							functionArgs();
							}
						}

						setState(398);
						match(RightParen);
						}
						break;
					case 13:
						{
						_localctx = new MemberAccessExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(399);
						if (!(precpred(_ctx, 16))) throw new FailedPredicateException(this, "precpred(_ctx, 16)");
						setState(400);
						match(T__2);
						setState(401);
						match(Identifier);
						}
						break;
					case 14:
						{
						_localctx = new IndexOperatorExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(402);
						if (!(precpred(_ctx, 14))) throw new FailedPredicateException(this, "precpred(_ctx, 14)");
						setState(403);
						match(LeftBracket);
						setState(404);
						expression(0);
						setState(405);
						match(RightBracket);
						}
						break;
					}
					} 
				}
				setState(411);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,34,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class FieldInitializerContext extends ParserRuleContext {
		public TerminalNode Identifier() { return getToken(CcashParser.Identifier, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public FieldInitializerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fieldInitializer; }
	}

	public final FieldInitializerContext fieldInitializer() throws RecognitionException {
		FieldInitializerContext _localctx = new FieldInitializerContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_fieldInitializer);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(412);
			match(Identifier);
			setState(413);
			match(T__7);
			setState(414);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 33:
			return expression_sempred((ExpressionContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expression_sempred(ExpressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 11);
		case 1:
			return precpred(_ctx, 10);
		case 2:
			return precpred(_ctx, 9);
		case 3:
			return precpred(_ctx, 8);
		case 4:
			return precpred(_ctx, 7);
		case 5:
			return precpred(_ctx, 6);
		case 6:
			return precpred(_ctx, 5);
		case 7:
			return precpred(_ctx, 4);
		case 8:
			return precpred(_ctx, 3);
		case 9:
			return precpred(_ctx, 2);
		case 10:
			return precpred(_ctx, 1);
		case 11:
			return precpred(_ctx, 18);
		case 12:
			return precpred(_ctx, 16);
		case 13:
			return precpred(_ctx, 14);
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3V\u01a3\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37\4 \t \4!"+
		"\t!\4\"\t\"\4#\t#\4$\t$\3\2\3\2\7\2K\n\2\f\2\16\2N\13\2\3\2\3\2\3\3\3"+
		"\3\3\3\3\4\3\4\3\4\3\4\5\4Y\n\4\3\4\3\4\5\4]\n\4\3\5\3\5\3\5\7\5b\n\5"+
		"\f\5\16\5e\13\5\3\6\3\6\3\6\5\6j\n\6\3\6\3\6\3\7\3\7\3\7\7\7q\n\7\f\7"+
		"\16\7t\13\7\3\b\3\b\3\b\3\b\3\b\7\b{\n\b\f\b\16\b~\13\b\3\b\3\b\3\t\3"+
		"\t\3\t\3\t\3\n\3\n\3\n\3\13\3\13\3\13\3\13\3\13\5\13\u008e\n\13\3\13\3"+
		"\13\5\13\u0092\n\13\3\f\3\f\3\f\3\f\3\r\3\r\3\r\3\16\3\16\3\17\3\17\3"+
		"\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\5\17\u00a9\n\17\3\20"+
		"\3\20\3\20\3\21\3\21\3\21\3\21\5\21\u00b2\n\21\3\22\3\22\3\22\3\22\5\22"+
		"\u00b8\n\22\3\23\3\23\3\23\3\23\5\23\u00be\n\23\5\23\u00c0\n\23\3\24\3"+
		"\24\3\24\3\24\3\24\3\24\3\24\5\24\u00c9\n\24\3\24\3\24\3\24\3\24\3\24"+
		"\3\24\3\24\3\24\3\24\3\24\3\24\3\24\3\24\3\24\3\24\3\24\5\24\u00db\n\24"+
		"\3\25\3\25\7\25\u00df\n\25\f\25\16\25\u00e2\13\25\3\25\3\25\3\26\3\26"+
		"\3\26\3\26\7\26\u00ea\n\26\f\26\16\26\u00ed\13\26\3\26\5\26\u00f0\n\26"+
		"\3\27\3\27\3\27\3\27\3\27\3\30\3\30\3\30\3\31\3\31\5\31\u00fc\n\31\3\31"+
		"\3\31\3\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32"+
		"\3\32\3\32\3\32\3\32\3\32\3\32\5\32\u0113\n\32\3\33\3\33\3\33\3\34\3\34"+
		"\3\34\3\35\3\35\3\35\3\35\3\36\3\36\5\36\u0121\n\36\3\36\3\36\5\36\u0125"+
		"\n\36\3\36\3\36\5\36\u0129\n\36\3\37\3\37\3\37\3 \3 \3 \3 \3!\3!\3!\5"+
		"!\u0135\n!\3\"\3\"\5\"\u0139\n\"\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3"+
		"#\3#\3#\7#\u014a\n#\f#\16#\u014d\13#\5#\u014f\n#\3#\3#\3#\3#\3#\3#\3#"+
		"\3#\7#\u0159\n#\f#\16#\u015c\13#\3#\3#\3#\3#\3#\3#\5#\u0164\n#\3#\3#\3"+
		"#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3"+
		"#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\3#\5#\u018f\n#\3#\3#\3#\3"+
		"#\3#\3#\3#\3#\3#\7#\u019a\n#\f#\16#\u019d\13#\3$\3$\3$\3$\3$\2\3D%\2\4"+
		"\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,.\60\62\64\668:<>@BDF\2\20"+
		"\3\2,-\3\2\"$\4\2\13\25LL\3\2\"#\3\2CF\3\2GJ\3\2\6\7\3\2\26\27\4\2\60"+
		"\60\67\67\3\2\61\63\3\2/\60\3\2\b\t\3\2:=\3\2>?\2\u01d1\2L\3\2\2\2\4Q"+
		"\3\2\2\2\6T\3\2\2\2\b^\3\2\2\2\nf\3\2\2\2\fm\3\2\2\2\16u\3\2\2\2\20\u0081"+
		"\3\2\2\2\22\u0085\3\2\2\2\24\u0088\3\2\2\2\26\u0093\3\2\2\2\30\u0097\3"+
		"\2\2\2\32\u009a\3\2\2\2\34\u00a8\3\2\2\2\36\u00aa\3\2\2\2 \u00ad\3\2\2"+
		"\2\"\u00b3\3\2\2\2$\u00bf\3\2\2\2&\u00da\3\2\2\2(\u00dc\3\2\2\2*\u00e5"+
		"\3\2\2\2,\u00f1\3\2\2\2.\u00f6\3\2\2\2\60\u00f9\3\2\2\2\62\u0112\3\2\2"+
		"\2\64\u0114\3\2\2\2\66\u0117\3\2\2\28\u011a\3\2\2\2:\u011e\3\2\2\2<\u012a"+
		"\3\2\2\2>\u012d\3\2\2\2@\u0134\3\2\2\2B\u0138\3\2\2\2D\u0163\3\2\2\2F"+
		"\u019e\3\2\2\2HK\5\4\3\2IK\5\16\b\2JH\3\2\2\2JI\3\2\2\2KN\3\2\2\2LJ\3"+
		"\2\2\2LM\3\2\2\2MO\3\2\2\2NL\3\2\2\2OP\7\2\2\3P\3\3\2\2\2QR\5\6\4\2RS"+
		"\5(\25\2S\5\3\2\2\2TU\7!\2\2UV\7L\2\2VX\7\30\2\2WY\5\b\5\2XW\3\2\2\2X"+
		"Y\3\2\2\2YZ\3\2\2\2Z\\\7\31\2\2[]\5$\23\2\\[\3\2\2\2\\]\3\2\2\2]\7\3\2"+
		"\2\2^c\5\30\r\2_`\7\3\2\2`b\5\30\r\2a_\3\2\2\2be\3\2\2\2ca\3\2\2\2cd\3"+
		"\2\2\2d\t\3\2\2\2ec\3\2\2\2fg\5\32\16\2gi\7\30\2\2hj\5\f\7\2ih\3\2\2\2"+
		"ij\3\2\2\2jk\3\2\2\2kl\7\31\2\2l\13\3\2\2\2mr\5D#\2no\7\3\2\2oq\5D#\2"+
		"pn\3\2\2\2qt\3\2\2\2rp\3\2\2\2rs\3\2\2\2s\r\3\2\2\2tr\3\2\2\2uv\t\2\2"+
		"\2vw\7L\2\2w|\7\34\2\2x{\5\20\t\2y{\5\22\n\2zx\3\2\2\2zy\3\2\2\2{~\3\2"+
		"\2\2|z\3\2\2\2|}\3\2\2\2}\177\3\2\2\2~|\3\2\2\2\177\u0080\7\35\2\2\u0080"+
		"\17\3\2\2\2\u0081\u0082\5$\23\2\u0082\u0083\7L\2\2\u0083\u0084\7K\2\2"+
		"\u0084\21\3\2\2\2\u0085\u0086\5\24\13\2\u0086\u0087\5(\25\2\u0087\23\3"+
		"\2\2\2\u0088\u0089\7!\2\2\u0089\u008a\t\3\2\2\u008a\u008b\7L\2\2\u008b"+
		"\u008d\7\30\2\2\u008c\u008e\5\b\5\2\u008d\u008c\3\2\2\2\u008d\u008e\3"+
		"\2\2\2\u008e\u008f\3\2\2\2\u008f\u0091\7\31\2\2\u0090\u0092\5$\23\2\u0091"+
		"\u0090\3\2\2\2\u0091\u0092\3\2\2\2\u0092\25\3\2\2\2\u0093\u0094\5\30\r"+
		"\2\u0094\u0095\7B\2\2\u0095\u0096\5D#\2\u0096\27\3\2\2\2\u0097\u0098\5"+
		"\"\22\2\u0098\u0099\7L\2\2\u0099\31\3\2\2\2\u009a\u009b\t\4\2\2\u009b"+
		"\33\3\2\2\2\u009c\u00a9\7\25\2\2\u009d\u00a9\7\13\2\2\u009e\u00a9\7\f"+
		"\2\2\u009f\u00a9\7\r\2\2\u00a0\u00a9\7\16\2\2\u00a1\u00a9\7\17\2\2\u00a2"+
		"\u00a9\7\20\2\2\u00a3\u00a9\7\21\2\2\u00a4\u00a9\7\22\2\2\u00a5\u00a9"+
		"\7\23\2\2\u00a6\u00a9\7\24\2\2\u00a7\u00a9\7L\2\2\u00a8\u009c\3\2\2\2"+
		"\u00a8\u009d\3\2\2\2\u00a8\u009e\3\2\2\2\u00a8\u009f\3\2\2\2\u00a8\u00a0"+
		"\3\2\2\2\u00a8\u00a1\3\2\2\2\u00a8\u00a2\3\2\2\2\u00a8\u00a3\3\2\2\2\u00a8"+
		"\u00a4\3\2\2\2\u00a8\u00a5\3\2\2\2\u00a8\u00a6\3\2\2\2\u00a8\u00a7\3\2"+
		"\2\2\u00a9\35\3\2\2\2\u00aa\u00ab\7+\2\2\u00ab\u00ac\5\34\17\2\u00ac\37"+
		"\3\2\2\2\u00ad\u00b1\7\4\2\2\u00ae\u00b2\5\34\17\2\u00af\u00b2\5\36\20"+
		"\2\u00b0\u00b2\5 \21\2\u00b1\u00ae\3\2\2\2\u00b1\u00af\3\2\2\2\u00b1\u00b0"+
		"\3\2\2\2\u00b2!\3\2\2\2\u00b3\u00b7\t\5\2\2\u00b4\u00b8\5\34\17\2\u00b5"+
		"\u00b8\5\36\20\2\u00b6\u00b8\5 \21\2\u00b7\u00b4\3\2\2\2\u00b7\u00b5\3"+
		"\2\2\2\u00b7\u00b6\3\2\2\2\u00b8#\3\2\2\2\u00b9\u00c0\5\34\17\2\u00ba"+
		"\u00bd\t\5\2\2\u00bb\u00be\5\36\20\2\u00bc\u00be\5 \21\2\u00bd\u00bb\3"+
		"\2\2\2\u00bd\u00bc\3\2\2\2\u00be\u00c0\3\2\2\2\u00bf\u00b9\3\2\2\2\u00bf"+
		"\u00ba\3\2\2\2\u00c0%\3\2\2\2\u00c1\u00db\5(\25\2\u00c2\u00db\5*\26\2"+
		"\u00c3\u00c4\5D#\2\u00c4\u00c5\7\5\2\2\u00c5\u00c6\7L\2\2\u00c6\u00c8"+
		"\7\30\2\2\u00c7\u00c9\5\f\7\2\u00c8\u00c7\3\2\2\2\u00c8\u00c9\3\2\2\2"+
		"\u00c9\u00ca\3\2\2\2\u00ca\u00cb\7\31\2\2\u00cb\u00cc\7K\2\2\u00cc\u00db"+
		"\3\2\2\2\u00cd\u00ce\5\n\6\2\u00ce\u00cf\7K\2\2\u00cf\u00db\3\2\2\2\u00d0"+
		"\u00d1\5\26\f\2\u00d1\u00d2\7K\2\2\u00d2\u00db\3\2\2\2\u00d3\u00d4\5\62"+
		"\32\2\u00d4\u00d5\7K\2\2\u00d5\u00db\3\2\2\2\u00d6\u00db\5\66\34\2\u00d7"+
		"\u00db\58\35\2\u00d8\u00db\5<\37\2\u00d9\u00db\5\60\31\2\u00da\u00c1\3"+
		"\2\2\2\u00da\u00c2\3\2\2\2\u00da\u00c3\3\2\2\2\u00da\u00cd\3\2\2\2\u00da"+
		"\u00d0\3\2\2\2\u00da\u00d3\3\2\2\2\u00da\u00d6\3\2\2\2\u00da\u00d7\3\2"+
		"\2\2\u00da\u00d8\3\2\2\2\u00da\u00d9\3\2\2\2\u00db\'\3\2\2\2\u00dc\u00e0"+
		"\7\34\2\2\u00dd\u00df\5&\24\2\u00de\u00dd\3\2\2\2\u00df\u00e2\3\2\2\2"+
		"\u00e0\u00de\3\2\2\2\u00e0\u00e1\3\2\2\2\u00e1\u00e3\3\2\2\2\u00e2\u00e0"+
		"\3\2\2\2\u00e3\u00e4\7\35\2\2\u00e4)\3\2\2\2\u00e5\u00e6\7%\2\2\u00e6"+
		"\u00e7\5D#\2\u00e7\u00eb\5(\25\2\u00e8\u00ea\5,\27\2\u00e9\u00e8\3\2\2"+
		"\2\u00ea\u00ed\3\2\2\2\u00eb\u00e9\3\2\2\2\u00eb\u00ec\3\2\2\2\u00ec\u00ef"+
		"\3\2\2\2\u00ed\u00eb\3\2\2\2\u00ee\u00f0\5.\30\2\u00ef\u00ee\3\2\2\2\u00ef"+
		"\u00f0\3\2\2\2\u00f0+\3\2\2\2\u00f1\u00f2\7&\2\2\u00f2\u00f3\7%\2\2\u00f3"+
		"\u00f4\5D#\2\u00f4\u00f5\5(\25\2\u00f5-\3\2\2\2\u00f6\u00f7\7&\2\2\u00f7"+
		"\u00f8\5(\25\2\u00f8/\3\2\2\2\u00f9\u00fb\7 \2\2\u00fa\u00fc\5D#\2\u00fb"+
		"\u00fa\3\2\2\2\u00fb\u00fc\3\2\2\2\u00fc\u00fd\3\2\2\2\u00fd\u00fe\7K"+
		"\2\2\u00fe\61\3\2\2\2\u00ff\u0100\5D#\2\u0100\u0101\7A\2\2\u0101\u0102"+
		"\5D#\2\u0102\u0113\3\2\2\2\u0103\u0104\5D#\2\u0104\u0105\7B\2\2\u0105"+
		"\u0106\5D#\2\u0106\u0113\3\2\2\2\u0107\u0108\5D#\2\u0108\u0109\t\6\2\2"+
		"\u0109\u010a\5D#\2\u010a\u0113\3\2\2\2\u010b\u010c\5D#\2\u010c\u010d\t"+
		"\7\2\2\u010d\u010e\5D#\2\u010e\u0113\3\2\2\2\u010f\u0110\5D#\2\u0110\u0111"+
		"\t\b\2\2\u0111\u0113\3\2\2\2\u0112\u00ff\3\2\2\2\u0112\u0103\3\2\2\2\u0112"+
		"\u0107\3\2\2\2\u0112\u010b\3\2\2\2\u0112\u010f\3\2\2\2\u0113\63\3\2\2"+
		"\2\u0114\u0115\7\'\2\2\u0115\u0116\5D#\2\u0116\65\3\2\2\2\u0117\u0118"+
		"\5\64\33\2\u0118\u0119\5(\25\2\u0119\67\3\2\2\2\u011a\u011b\7(\2\2\u011b"+
		"\u011c\5(\25\2\u011c\u011d\5\64\33\2\u011d9\3\2\2\2\u011e\u0120\7)\2\2"+
		"\u011f\u0121\5@!\2\u0120\u011f\3\2\2\2\u0120\u0121\3\2\2\2\u0121\u0122"+
		"\3\2\2\2\u0122\u0124\7K\2\2\u0123\u0125\5D#\2\u0124\u0123\3\2\2\2\u0124"+
		"\u0125\3\2\2\2\u0125\u0126\3\2\2\2\u0126\u0128\7K\2\2\u0127\u0129\5B\""+
		"\2\u0128\u0127\3\2\2\2\u0128\u0129\3\2\2\2\u0129;\3\2\2\2\u012a\u012b"+
		"\5:\36\2\u012b\u012c\5(\25\2\u012c=\3\2\2\2\u012d\u012e\7.\2\2\u012e\u012f"+
		"\5D#\2\u012f\u0130\5(\25\2\u0130?\3\2\2\2\u0131\u0135\5\n\6\2\u0132\u0135"+
		"\5\26\f\2\u0133\u0135\5\62\32\2\u0134\u0131\3\2\2\2\u0134\u0132\3\2\2"+
		"\2\u0134\u0133\3\2\2\2\u0135A\3\2\2\2\u0136\u0139\5\n\6\2\u0137\u0139"+
		"\5\62\32\2\u0138\u0136\3\2\2\2\u0138\u0137\3\2\2\2\u0139C\3\2\2\2\u013a"+
		"\u013b\b#\1\2\u013b\u013c\7\30\2\2\u013c\u013d\5D#\2\u013d\u013e\7\31"+
		"\2\2\u013e\u0164\3\2\2\2\u013f\u0164\7N\2\2\u0140\u0164\7O\2\2\u0141\u0164"+
		"\7P\2\2\u0142\u0164\7Q\2\2\u0143\u0164\7R\2\2\u0144\u0145\7L\2\2\u0145"+
		"\u014e\7\34\2\2\u0146\u014b\5F$\2\u0147\u0148\7\3\2\2\u0148\u014a\5F$"+
		"\2\u0149\u0147\3\2\2\2\u014a\u014d\3\2\2\2\u014b\u0149\3\2\2\2\u014b\u014c"+
		"\3\2\2\2\u014c\u014f\3\2\2\2\u014d\u014b\3\2\2\2\u014e\u0146\3\2\2\2\u014e"+
		"\u014f\3\2\2\2\u014f\u0150\3\2\2\2\u0150\u0164\7\35\2\2\u0151\u0164\7"+
		"L\2\2\u0152\u0164\t\t\2\2\u0153\u0164\5\n\6\2\u0154\u0155\7\32\2\2\u0155"+
		"\u015a\5D#\2\u0156\u0157\7\3\2\2\u0157\u0159\5D#\2\u0158\u0156\3\2\2\2"+
		"\u0159\u015c\3\2\2\2\u015a\u0158\3\2\2\2\u015a\u015b\3\2\2\2\u015b\u015d"+
		"\3\2\2\2\u015c\u015a\3\2\2\2\u015d\u015e\7\33\2\2\u015e\u0164\3\2\2\2"+
		"\u015f\u0160\7+\2\2\u0160\u0164\7L\2\2\u0161\u0162\t\n\2\2\u0162\u0164"+
		"\5D#\16\u0163\u013a\3\2\2\2\u0163\u013f\3\2\2\2\u0163\u0140\3\2\2\2\u0163"+
		"\u0141\3\2\2\2\u0163\u0142\3\2\2\2\u0163\u0143\3\2\2\2\u0163\u0144\3\2"+
		"\2\2\u0163\u0151\3\2\2\2\u0163\u0152\3\2\2\2\u0163\u0153\3\2\2\2\u0163"+
		"\u0154\3\2\2\2\u0163\u015f\3\2\2\2\u0163\u0161\3\2\2\2\u0164\u019b\3\2"+
		"\2\2\u0165\u0166\f\r\2\2\u0166\u0167\t\13\2\2\u0167\u019a\5D#\16\u0168"+
		"\u0169\f\f\2\2\u0169\u016a\t\f\2\2\u016a\u019a\5D#\r\u016b\u016c\f\13"+
		"\2\2\u016c\u016d\t\r\2\2\u016d\u019a\5D#\f\u016e\u016f\f\n\2\2\u016f\u0170"+
		"\t\16\2\2\u0170\u019a\5D#\13\u0171\u0172\f\t\2\2\u0172\u0173\t\17\2\2"+
		"\u0173\u019a\5D#\n\u0174\u0175\f\b\2\2\u0175\u0176\7\64\2\2\u0176\u019a"+
		"\5D#\t\u0177\u0178\f\7\2\2\u0178\u0179\7\66\2\2\u0179\u019a\5D#\b\u017a"+
		"\u017b\f\6\2\2\u017b\u017c\7\65\2\2\u017c\u019a\5D#\7\u017d\u017e\f\5"+
		"\2\2\u017e\u017f\78\2\2\u017f\u019a\5D#\6\u0180\u0181\f\4\2\2\u0181\u0182"+
		"\79\2\2\u0182\u019a\5D#\5\u0183\u0184\f\3\2\2\u0184\u0185\7@\2\2\u0185"+
		"\u0186\5D#\2\u0186\u0187\7\n\2\2\u0187\u0188\5D#\4\u0188\u019a\3\2\2\2"+
		"\u0189\u018a\f\24\2\2\u018a\u018b\7\5\2\2\u018b\u018c\7L\2\2\u018c\u018e"+
		"\7\30\2\2\u018d\u018f\5\f\7\2\u018e\u018d\3\2\2\2\u018e\u018f\3\2\2\2"+
		"\u018f\u0190\3\2\2\2\u0190\u019a\7\31\2\2\u0191\u0192\f\22\2\2\u0192\u0193"+
		"\7\5\2\2\u0193\u019a\7L\2\2\u0194\u0195\f\20\2\2\u0195\u0196\7\32\2\2"+
		"\u0196\u0197\5D#\2\u0197\u0198\7\33\2\2\u0198\u019a\3\2\2\2\u0199\u0165"+
		"\3\2\2\2\u0199\u0168\3\2\2\2\u0199\u016b\3\2\2\2\u0199\u016e\3\2\2\2\u0199"+
		"\u0171\3\2\2\2\u0199\u0174\3\2\2\2\u0199\u0177\3\2\2\2\u0199\u017a\3\2"+
		"\2\2\u0199\u017d\3\2\2\2\u0199\u0180\3\2\2\2\u0199\u0183\3\2\2\2\u0199"+
		"\u0189\3\2\2\2\u0199\u0191\3\2\2\2\u0199\u0194\3\2\2\2\u019a\u019d\3\2"+
		"\2\2\u019b\u0199\3\2\2\2\u019b\u019c\3\2\2\2\u019cE\3\2\2\2\u019d\u019b"+
		"\3\2\2\2\u019e\u019f\7L\2\2\u019f\u01a0\7\n\2\2\u01a0\u01a1\5D#\2\u01a1"+
		"G\3\2\2\2%JLX\\cirz|\u008d\u0091\u00a8\u00b1\u00b7\u00bd\u00bf\u00c8\u00da"+
		"\u00e0\u00eb\u00ef\u00fb\u0112\u0120\u0124\u0128\u0134\u0138\u014b\u014e"+
		"\u015a\u0163\u018e\u0199\u019b";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}